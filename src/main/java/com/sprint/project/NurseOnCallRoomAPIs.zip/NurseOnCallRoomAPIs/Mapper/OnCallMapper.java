package com.sprint.project.NurseOnCallRoomAPIs.Mapper;

public class OnCallMapper {
}
